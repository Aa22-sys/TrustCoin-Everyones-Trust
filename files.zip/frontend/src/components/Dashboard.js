import { useTable } from "@tableland/react";

export default function Dashboard() {
  const { data } = useTable(
    "SELECT * FROM monitor_80001_1 ORDER BY timestamp DESC LIMIT 10"
  );

  return (
    <div>
      <h2>系统实时状态</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>状态</th>
            <th>时间戳</th>
          </tr>
        </thead>
        <tbody>
          {data?.map((row) => (
            <tr key={row.id}>
              <td>{row.id}</td>
              <td>{row.status}</td>
              <td>{row.timestamp}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}