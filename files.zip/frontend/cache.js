import { ThirdwebSDK } from "@thirdweb/sdk";

const sdk = new ThirdwebSDK("mumbai", { 
  clientId: "FREE_CLIENT_ID", 
  cache: true 
});